package com.example.demo.controller;

import com.baomidou.mybatisplus.core.conditions.Wrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.example.demo.common.Result;
import com.example.demo.entity.User;
import com.example.demo.mapper.UserMapper;
import com.example.demo.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

@RestController
@RequestMapping("/user")
@CrossOrigin
public class UserController {
    @Resource
    UserMapper userMapper;

    @Autowired
    UserService userService;

    @PostMapping("/register")
    public Result<?> save(@RequestBody User user){
        User res = userMapper.selectOne(Wrappers.<User>lambdaQuery().eq(User::getUid,user.getUid()));
        if(res!=null){
            return Result.error("-1","ID已被占用，请重试！");
        }
        userMapper.insert(user);
        return Result.success();
    }

    @PostMapping("/login")
    public Result<?> login(@RequestBody User user){
        User res = userMapper.selectOne(Wrappers.<User>lambdaQuery().eq(User::getUid,user.getUid()).eq(User::getPassword,user.getPassword()));
        if(res==null){
            return Result.error("-1","ID或密码错误！");
        }
        return Result.success(res);
    }

    @GetMapping("byid") Result<?> byid(@RequestParam String uid){
        User user = userMapper.selectById(uid);
        if(user == null){
            return Result.error("-1","用户不存在");
        }
        return Result.success(user);
    }

    @PostMapping("/avatar")
    public Result<?> avatar(@RequestBody MultipartFile pic, String uid){
        String res = userService.updateAvatar(pic, uid);
        if(res.equals("failed"))
            return Result.error("-1","上传失败！");
        else
            return Result.success();
    }

    @GetMapping("/getavatar")
    public Result<?> avatar(String uid) {
        User user = userMapper.selectById(uid);
        byte[] pic = user.getAvatar();
        return Result.success(pic);
    }
}
